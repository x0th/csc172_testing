import java.util.Arrays;

public class Lab1 {
	
	public static boolean isAnagram(String str1, String str2) {
		return false;
	}

	public static boolean isRotation(String str1, String str2) 
    {   
        return false;
    }

    public static void main(String[] args) {
    	// main
    } 

}