import java.util.Arrays;

public class Lab1 {
	
	public static boolean isAnagram(String str1, String str2) {

		// creating arrays of characters from given strings for easier operation
		char[] arr1 = str1.toCharArray();
		char[] arr2 = str2.toCharArray();

		// starting check on the length of the strings, if not the same length cannot be
		// anagrams
		if (arr1.length != arr2.length) {
			return false;
		}

		// sorting both arrays
		Arrays.sort(arr1);
		Arrays.sort(arr2);

		// assembling char arrays back into strings
		String ret1 = String.valueOf(arr1);
		String ret2 = String.valueOf(arr2);

		// final check on the 'sorted' strings
		if (ret1.equals(ret2)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isRotation(String str1, String str2) 
    {   
        return (str1.length() == str2.length()) && 
               ((str1 + str1).indexOf(str2) != -1); 
    }

    public static void main(String[] args) {
    	// main
    } 

}